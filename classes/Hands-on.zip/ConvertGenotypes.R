Convert_SNPdata = function (SNPfile = NULL, missingValue, outFile = NULL, separator = "", keepMono = FALSE, codes = c(0,1,2)){
	Time = proc.time()
	if(is.null(SNPfile)){
		stop(deparse("Please define the path for SNPfile"))
	}
	welcome_conv_geno()
	if (missing(missingValue)){ stop(deparse("missingValue not defined"))}
	file = read.csv(SNPfile,header = TRUE,check.names = FALSE,row.names = 1,na.strings = missingValue)
	snpData = as.matrix(file)
	snpData[which(snpData=="NA")]=NA
	ref = matrix(0,nrow = ncol(snpData),2)
#	pb <- txtProgressBar(min = 0, max = floor(ncol(snpData)/100), style = 3)
	pb <- txtProgressBar(min = 0, max = 100, style = 3)
	for (i in 1:ncol(snpData)){
		x = table(snpData[,i],useNA = "no", exclude = c("NA",NA,NaN))
		x = sort(x)
		if (length(x) == 0){
			ref[i,1] = i
			ref[i,2] = colnames(snpData)[i]
      snpData[,i] = NA
#			next(i)
		} else if (length(x) == 1){
			ref[i,1] = i
			ref[i,2] = names(x)
			snpData[,i] = codes[3]
#			next(i)
		} else {
			HET = 0
			splt = matrix(unlist(strsplit(names(x),separator)),ncol = 2,byrow = T)
			if (any(splt[,1] != splt[,2])){
				HET = which(splt[,1] != splt[,2])
			} else {
				HET = 0
			}
			if (length(x) == 2){
				if (HET == 1){
					snpData[which(snpData[,i]==names(x)[1]),i] = codes[2]
					snpData[which(snpData[,i]==names(x)[2]),i] = codes[3]
				} else {
					if (HET == 2){
						snpData[which(snpData[,i]==names(x)[1]),i] = codes[3]
						snpData[which(snpData[,i]==names(x)[2]),i] = codes[2]
					} else {
						snpData[which(snpData[,i]==names(x)[1]),i] = codes[1]
						snpData[which(snpData[,i]==names(x)[2]),i] = codes[3]
					}
				}
			} else {
				if (HET == 2){
						snpData[which(snpData[,i]==names(x)[1]),i] = codes[1]
						snpData[which(snpData[,i]==names(x)[2]),i] = codes[2]
						snpData[which(snpData[,i]==names(x)[3]),i] = codes[3]
				} else {
					if (HET == 1){
						snpData[which(snpData[,i]==names(x)[1]),i] = codes[2]
						snpData[which(snpData[,i]==names(x)[2]),i] = codes[1]
						snpData[which(snpData[,i]==names(x)[3]),i] = codes[3]
					} else {
						snpData[which(snpData[,i]==names(x)[1]),i] = codes[1]
						snpData[which(snpData[,i]==names(x)[2]),i] = codes[3]
						snpData[which(snpData[,i]==names(x)[3]),i] = codes[2]
					}
				}
			}
		}
		if (i%%100==0){
			setTxtProgressBar(pb, (i*100)/ncol(snpData))
		}
	}

  if (keepMono == FALSE){
	  ref1 = as.matrix(ref[which(ref[,1]!=0),1])
    ref1 = matrix(as.numeric(ref1),ncol =1)
    if (nrow(ref1)>0){
      snpData = snpData[,-ref1]
    }
  }
  snpData1 = matrix(as.numeric(snpData),ncol = ncol(snpData),dimnames = list(c(rownames(snpData)),c(colnames(snpData))))
    if (!is.null(outFile)) {
        write.csv(snpData1, outFile)
	} else {
		return(snpData1)
	}
	close(pb)
	flush.console()
#	flush(pb)
	Time = as.matrix(proc.time()-Time)
	cat("\n Completed! Time =", Time[3]," seconds \n")
}
welcome_conv_geno = function(){
	message("
	##############################################
		R script to convert base-pair genotypic
			file to c(0,1,2) codes 
			contact: Marcio Resende Jr.
					 mresende@ufl.edu	
	##############################################")
}